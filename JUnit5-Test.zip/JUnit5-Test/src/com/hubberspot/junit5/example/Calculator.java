package com.hubberspot.junit5.example;

public class Calculator {

	public boolean isEvenNumber(int number) {
		return number % 2 == 0;
	}
	
}
