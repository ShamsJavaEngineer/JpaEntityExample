package com.hubberspot.junit5.test.annotation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class TestAnnotationDemo {

	@Test
	void test() {
		assertEquals(3, 2);
	}
	
}
