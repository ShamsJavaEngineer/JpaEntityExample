package com.hubberspot.junit5.first.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FirstJunit5Test {

	@Test
	void test() {
		fail();
	}

}
