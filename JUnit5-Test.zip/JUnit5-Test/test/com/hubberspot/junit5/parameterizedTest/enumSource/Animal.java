package com.hubberspot.junit5.parameterizedTest.enumSource;

public enum Animal {
	DOG,
	CAT,
	LION,
	TIGER,
	DONKEY
}
