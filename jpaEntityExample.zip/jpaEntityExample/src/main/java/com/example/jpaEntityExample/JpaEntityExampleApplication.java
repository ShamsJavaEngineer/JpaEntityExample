package com.example.jpaEntityExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaEntityExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaEntityExampleApplication.class, args);
	}

}
